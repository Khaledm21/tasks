
using System;
using System.Drawing;
using System.Text;

class Steganography
{
    static void Main()
    {
        Console.WriteLine("Steganography - Text Hiding in Images");
        Console.WriteLine("1. Encode Text into Image");
        Console.WriteLine("2. Decode Text from Image");
        Console.Write("Choose an option (1/2): ");
        string option = Console.ReadLine();

        if (option == "1")
        {
            Console.Write("Enter the path of the source image: ");
            string inputImagePath = Console.ReadLine();

            Console.Write("Enter the text to hide: ");
            string textToHide = Console.ReadLine();

            Console.Write("Enter the path to save the output image: ");
            string outputImagePath = Console.ReadLine();

            EncodeTextIntoImage(inputImagePath, textToHide, outputImagePath);
        }
        else if (option == "2")
        {
            Console.Write("Enter the path of the image to decode: ");
            string inputImagePath = Console.ReadLine();

            string extractedText = DecodeTextFromImage(inputImagePath);
            Console.WriteLine("Extracted Text:");
            Console.WriteLine(extractedText);
        }
        else
        {
            Console.WriteLine("Invalid option.");
        }
    }

    static void EncodeTextIntoImage(string inputImagePath, string textToHide, string outputImagePath)
    {
        Bitmap bmp = new Bitmap(inputImagePath);

        byte[] textBytes = Encoding.UTF8.GetBytes(textToHide);
        byte[] lengthBytes = BitConverter.GetBytes(textBytes.Length);

        int totalBytes = lengthBytes.Length + textBytes.Length;
        if (totalBytes * 8 > bmp.Width * bmp.Height * 3)
        {
            Console.WriteLine("Error: Text is too large to hide in this image.");
            return;
        }

        byte[] allBytes = new byte[totalBytes];
        Array.Copy(lengthBytes, allBytes, lengthBytes.Length);
        Array.Copy(textBytes, 0, allBytes, lengthBytes.Length, textBytes.Length);

        int byteIndex = 0, bitIndex = 0;

        for (int y = 0; y < bmp.Height && byteIndex < allBytes.Length; y++)
        {
            for (int x = 0; x < bmp.Width && byteIndex < allBytes.Length; x++)
            {
                Color pixel = bmp.GetPixel(x, y);

                byte R = pixel.R;
                byte G = pixel.G;
                byte B = pixel.B;

                R = SetLeastSignificantBit(R, GetBit(allBytes[byteIndex], bitIndex++));
                if (bitIndex == 8) { bitIndex = 0; byteIndex++; }
                if (byteIndex >= allBytes.Length) { bmp.SetPixel(x, y, Color.FromArgb(R, G, B)); break; }

                G = SetLeastSignificantBit(G, GetBit(allBytes[byteIndex], bitIndex++));
                if (bitIndex == 8) { bitIndex = 0; byteIndex++; }
                if (byteIndex >= allBytes.Length) { bmp.SetPixel(x, y, Color.FromArgb(R, G, B)); break; }

                B = SetLeastSignificantBit(B, GetBit(allBytes[byteIndex], bitIndex++));
                if (bitIndex == 8) { bitIndex = 0; byteIndex++; }

                bmp.SetPixel(x, y, Color.FromArgb(R, G, B));
            }
        }

        bmp.Save(outputImagePath);
        bmp.Dispose();

        Console.WriteLine("Text successfully hidden and image saved.");
    }

    static string DecodeTextFromImage(string inputImagePath)
    {
        Bitmap bmp = new Bitmap(inputImagePath);

        byte[] lengthBytes = new byte[4];
        int byteIndex = 0, bitIndex = 0;

        for (int y = 0; y < bmp.Height && byteIndex < 4; y++)
        {
            for (int x = 0; x < bmp.Width && byteIndex < 4; x++)
            {
                Color pixel = bmp.GetPixel(x, y);

                lengthBytes[byteIndex] = SetBit(lengthBytes[byteIndex], bitIndex++, GetLeastSignificantBit(pixel.R));
                if (bitIndex == 8) { bitIndex = 0; byteIndex++; }
                if (byteIndex >= 4) break;

                lengthBytes[byteIndex] = SetBit(lengthBytes[byteIndex], bitIndex++, GetLeastSignificantBit(pixel.G));
                if (bitIndex == 8) { bitIndex = 0; byteIndex++; }
                if (byteIndex >= 4) break;

                lengthBytes[byteIndex] = SetBit(lengthBytes[byteIndex], bitIndex++, GetLeastSignificantBit(pixel.B));
                if (bitIndex == 8) { bitIndex = 0; byteIndex++; }
            }
        }

        int messageLength = BitConverter.ToInt32(lengthBytes, 0);
        byte[] messageBytes = new byte[messageLength];

        byteIndex = 0;
        bitIndex = 0;
        int pixelCount = 0;

        for (int y = 0; y < bmp.Height && byteIndex < messageLength; y++)
        {
            for (int x = 0; x < bmp.Width && byteIndex < messageLength; x++)
            {
                if (pixelCount < 4 * 8 / 3)
                {
                    pixelCount++;
                    continue;
                }

                Color pixel = bmp.GetPixel(x, y);

                messageBytes[byteIndex] = SetBit(messageBytes[byteIndex], bitIndex++, GetLeastSignificantBit(pixel.R));
                if (bitIndex == 8) { bitIndex = 0; byteIndex++; }
                if (byteIndex >= messageLength) break;

                messageBytes[byteIndex] = SetBit(messageBytes[byteIndex], bitIndex++, GetLeastSignificantBit(pixel.G));
                if (bitIndex == 8) { bitIndex = 0; byteIndex++; }
                if (byteIndex >= messageLength) break;

                messageBytes[byteIndex] = SetBit(messageBytes[byteIndex], bitIndex++, GetLeastSignificantBit(pixel.B));
                if (bitIndex == 8) { bitIndex = 0; byteIndex++; }
            }
        }

        bmp.Dispose();
        return Encoding.UTF8.GetString(messageBytes);
    }

    static byte SetLeastSignificantBit(byte b, int bit)
    {
        return (byte)((b & 0xFE) | bit);
    }

    static int GetLeastSignificantBit(byte b)
    {
        return b & 1;
    }

    static int GetBit(byte b, int bitIndex)
    {
        return (b >> (7 - bitIndex)) & 1;
    }

    static byte SetBit(byte b, int bitIndex, int bitValue)
    {
        if (bitValue == 1)
            return (byte)(b | (1 << (7 - bitIndex)));
        else
            return (byte)(b & ~(1 << (7 - bitIndex)));
    }
}
